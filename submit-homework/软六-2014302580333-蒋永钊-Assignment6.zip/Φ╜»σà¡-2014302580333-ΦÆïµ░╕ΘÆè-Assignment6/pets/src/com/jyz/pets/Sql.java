package com.jyz.pets;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Sql {
	
	public static  ArrayList<String>  getArrayListPetId(String userName) throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.jdbc.Driver");
		Connection connection=
				DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
		Statement statement=connection.createStatement();
		ArrayList<String> arrayListPetId = new ArrayList<String>();
		String sql = "select * from 2014302580333_petIds where name='"+userName+"'";
		
		ResultSet resultSet = statement.executeQuery(sql);
		System.out.println("-----------------"+userName+"拥有宠物编号：---------------------");
		while(resultSet.next()){
			String petId=String.valueOf(resultSet.getString("petId"));
			System.out.println(petId);
			arrayListPetId.add(petId);
		}
		System.out.println("--------------------------------------------------------------");
		return arrayListPetId;
	}
	
	public static  ArrayList<String>  getArrayListComment(int petId) throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.jdbc.Driver");
		Connection connection=
				DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
		Statement statement=connection.createStatement();
		String sql = "select * from 2014302580333_comments where petId='"+petId+"'";
		ResultSet resultSet = statement.executeQuery(sql);
		
		ArrayList<String> arrayListComment = new ArrayList<String>();
		System.out.println("-----------------"+petId+"号宠物评价：---------------------");
		while(resultSet.next()){
			String name =resultSet.getString("name");
			String time=resultSet.getString("time");
			String comment=resultSet.getString("comment");
			System.out.println(name+"  "+time+"  "+comment);
			
			arrayListComment.add(name);
			arrayListComment.add(time);
			arrayListComment.add(comment);
		}
		System.out.println("--------------------------------------------------------------");
		return arrayListComment;
	}
	
	public static ArrayList<String>  getArrayListPet () throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.jdbc.Driver");
		Connection connection=
				DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
		Statement statement=connection.createStatement();
		ArrayList<String> arrayListPet = new ArrayList<String>();
		System.out.println("---------------------------宠物商店宠物信息---------------------");
		String sql = "select * from 2014302580333_pets";
		ResultSet resultSet = statement.executeQuery(sql);
		while(resultSet.next()){
			String name =resultSet.getString("name");
			String eat=resultSet.getString("eat");
			String drink=resultSet.getString("drink");
			String live =resultSet.getString("live");
			String hobby=resultSet.getString("hobby");
			String price=String.valueOf(resultSet.getString("price"));
			System.out.println(name+"  "+eat+"  "+drink+"  "+live+"  "+hobby+"  "+price);
			
			arrayListPet.add(name);
			arrayListPet.add(eat);
			arrayListPet.add(drink);
			arrayListPet.add(live);
			arrayListPet.add(hobby);
			arrayListPet.add(price);
			}
		System.out.println("--------------------------------------------------------------");
		return arrayListPet;
	}

	public static ArrayList<String>  getArrayListUser (String name) throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.jdbc.Driver");
		Connection connection=
				DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
		Statement statement=connection.createStatement();
		ArrayList<String> arrayListUser = new ArrayList<String>();
		String sql = "select * from 2014302580333_users where name='" +name+"'";
		ResultSet resultSet = statement.executeQuery(sql);
		System.out.println("---------------------------当前用户信息---------------------");
		if(resultSet.next()){
			String userName=resultSet.getString("name");
			String password=resultSet.getString("password");
			String emailUrl=resultSet.getString("emailUrl");
			String money=String.valueOf(resultSet.getString("money"));
			System.out.println(userName+"  "+password+"  "+emailUrl+"  "+money);
			
			arrayListUser.add(userName);
			arrayListUser.add(password);
			arrayListUser.add(emailUrl);
			arrayListUser.add(money);
		}
		System.out.println("--------------------------------------------------------------");
		return arrayListUser;
	}
	
	public static boolean getPet(ArrayList<String>  arrayListPetId,int petId) throws ClassNotFoundException, SQLException{
		Boolean have=false;
		if(!arrayListPetId.isEmpty()){
			for(int i=0;i<arrayListPetId.size();i++){
				if(Integer.valueOf(arrayListPetId.get(i))==petId){
					have=true;
				}
			}
		}
		return have;
	}
	
	public static void buy(String userName,int petId) throws SQLException, ClassNotFoundException{
		int money = 0;
		int price = 0;
		Class.forName("com.mysql.jdbc.Driver");
		Connection connection=
				DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
		Statement statement=connection.createStatement();
		String sql = "select * from 2014302580333_users where name='"+userName+"'";
		ResultSet resultSet = statement.executeQuery(sql);
		if(resultSet.next()){
			money=Integer.valueOf(resultSet.getString("money"));
		}
		sql = "select * from 2014302580333_pets where id='" +petId+"'";
		resultSet = statement.executeQuery(sql);
		if(resultSet.next()){
			price=Integer.valueOf(resultSet.getString("price"));
		}
		money=money-price;
		sql="update 2014302580333_users set money="+money+" where name='"+userName+"'";
		statement.executeUpdate(sql);
		System.out.println("已从"+userName+"账户扣除"+price+"元");
	}
	
	public static void setUser(String name,String password,String emailUrl) throws SQLException, ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
		Connection connection=
				DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
		Statement statement=connection.createStatement();
		statement.execute("create table if not exists 2014302580333_users "
				+ "(name varchar(255),password varchar(255),emailUrl varchar(255),money int(11));");
		statement.execute("create table if not exists 2014302580333_comments "
				+ "(petId varchar(255),name varchar(255),time varchar(255),comment text);");
		statement.execute("create table if not exists 2014302580333_petIds "
				+ "(name varchar(255),petId int(11));");
		String sql = "insert into 2014302580333_users (name,password,emailUrl,money  ) values(?,?,?,?)";
		PreparedStatement preparedStatement = (PreparedStatement) connection.prepareStatement(sql);
		preparedStatement.setObject(1, name);
		preparedStatement.setObject(2, password);
		preparedStatement.setObject(3, emailUrl);
		preparedStatement.setObject(4, 1000);
		preparedStatement.executeUpdate();
		System.out.println("写入一个用户的信息： "+name+"  "+password+"  "+emailUrl+"  余额:"+1000);
	}
	
	public static void setComment(int petId,String name,String time,String comment) throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.jdbc.Driver");
		Connection connection=
				DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
		String sql = "insert into 2014302580333_comments (petId,name,time,comment) values(?,?,?,?)";
		PreparedStatement preparedStatement = (PreparedStatement) connection.prepareStatement(sql);
		preparedStatement.setObject(1, petId);
		preparedStatement.setObject(2, name);
		preparedStatement.setObject(3, time);
		preparedStatement.setObject(4, comment);
		preparedStatement.executeUpdate();
		System.out.println("写入一个宠物评价： 宠物编号-"+petId+"  "+name+"  "+time+"  "+comment);
		
	}
	
	public static void setPetId(String name,int petId) throws SQLException, ClassNotFoundException{
		Class.forName("com.mysql.jdbc.Driver");
		Connection connection=
				DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
		String sql = "insert into 2014302580333_petIds (name,petId) values(?,?)";
		PreparedStatement preparedStatement = (PreparedStatement) connection.prepareStatement(sql);
		preparedStatement.setObject(1, name);
		preparedStatement.setObject(2, petId);
		preparedStatement.executeUpdate();
		System.out.println("写入一个宠物购买记录： "+name+"  宠物编号-"+petId);
		
	}
}
