package com.jyz.pets;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.border.BevelBorder;

public class Gui extends JFrame {
	/*-----------------------------------------------------------------------------------------------------------------*/
	private static JFrame jFrame=new JFrame();
	private static Container container=jFrame.getContentPane();
	private ArrayList<String> arrayListPet;
	private ArrayList<String> arrayListUser;
	private ArrayList<String>  arrayListPetId;
	//send email
	private String contentEmail="";
	//jPanelLogin
	private JPanel jPanelLogin=new JPanel();
	private JPanel jPanelRegister=new JPanel();
	private JLabel jLabelNameL=new JLabel("帐号");
	private JTextField jTextFieldNameL=new JTextField("请输入英文帐号");
	private JLabel jLabelPasswordL=new JLabel("密码");
	private JTextField jTextFieldPasswordL=new JTextField("请输入密码");
	private JLabel jLabelNameR=new JLabel("帐号");
	private JTextField jTextFieldNameR=new JTextField("请输入英文帐号");
	private JLabel jLabelPasswordR=new JLabel("密码");
	private JTextField jTextFieldPasswordR=new JTextField("请输入邮箱获取的密码");
	private JLabel jLabelEmail=new JLabel("邮箱");
	private JTextField jTextFieldEmail=new JTextField("请输入邮箱");
	private JButton jButtonLogin=new JButton("登录");
	private JButton jButtonRegister=new JButton("注册");
	private JButton jButtonSend=new JButton("验证邮箱");
	private JButton jButtonConfirm=new JButton("确定");
	//title
	private JPanel jPanelTitle=new JPanel();
	private JButton jButtonHome=new JButton("首页");
	private JLabel jLabelTitle=new JLabel("",JLabel.CENTER);
	private JButton jButtonMine=new JButton("我的pets");
	//jScrollPaneAnimals
	private JScrollPane jScrollPaneAnimals=new JScrollPane();
	//jScrollPaneShowAnimals
	private JScrollPane jScrollPaneShowAnimal=new JScrollPane();
	private JTextArea jTextAreaComment=new JTextArea();
	private JTextArea jTextAreaPet=new JTextArea();
	private JButton jButtonBuy=new JButton("购买");
	private JTextArea jTextAreaSetComment=new JTextArea("购买后可以提交英文评价");
	private JButton jButtonComment=new JButton("提交评论");
	private ActionListener actionListenerJButtonBuy=null;
	private ActionListener actionListenerJButtonComment=null;
	//jLabelMine
	private JLabel jLabelMine=new JLabel("",JLabel.CENTER);
	
	
	
	/*-----------------------------------------------------------------------------------------------------------------*/
	public Gui() {
		// TODO Auto-generated constructor stub
		//初始商店宠物信息
		try {
			arrayListPet=Sql.getArrayListPet();
		} catch (ClassNotFoundException | SQLException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		//设置我的pets按钮功能
		jButtonMine.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.out.println("点击我的pets");
				try {
					creatJFrameMine(arrayListUser.get(0));
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				}
			});		
		//设置登录按钮功能
		jButtonLogin.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.out.println("点击登录");
				try {
					arrayListUser = Sql.getArrayListUser(jTextFieldNameL.getText());
					if(arrayListUser.isEmpty()){
						JOptionPane.showMessageDialog(null, "账户不存在", "消息提示",
								JOptionPane.INFORMATION_MESSAGE);
					}else{
						if(jTextFieldPasswordL.getText().matches(arrayListUser.get(1))){
							arrayListPetId=Sql.getArrayListPetId(arrayListUser.get(0));
							creatJFramePets();
						}else{
							JOptionPane.showMessageDialog(null, "密码输入错误", "消息提示",
									JOptionPane.INFORMATION_MESSAGE);
						}
					}
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		//设置注册按钮功能
		jButtonRegister.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.out.println("点击注册");
				creatJFrameRegister();
			}
		});
		//设置验证邮箱按钮功能
		jButtonSend.addActionListener(new ActionListener() {
			
			@Override
			public  void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.out.println("点击验证邮箱");
				if(isEmail(jTextFieldEmail.getText())){
					contentEmail="";
					for(int i=0;i<7;i++){
						int random = new Random().nextInt(10);
						contentEmail+=String.valueOf(random);
					}
					sendEmail(jTextFieldEmail.getText(), "欢迎注册pets", contentEmail);
					JOptionPane.showMessageDialog(null, "请查收注册邮件", "消息提示",
							JOptionPane.INFORMATION_MESSAGE);
				}else{
					JOptionPane.showMessageDialog(null, "请输入有效邮箱地址", "消息提示",
							JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		//设置确定按钮功能
		jButtonConfirm.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.out.println("点击确定");
				if(jTextFieldNameR.getText().matches("请输入英文帐号")|
						jTextFieldNameR.getText().matches("")|
						jTextFieldEmail.getText().matches("请输入邮箱")|
						jTextFieldEmail.getText().matches("")|
						jTextFieldPasswordR.getText().matches("请输入邮箱获取的密码")|
						jTextFieldPasswordR.getText().matches(""))
				{
					JOptionPane.showMessageDialog(null, "请完善注册信息", "消息提示",
							JOptionPane.INFORMATION_MESSAGE);
				}else{
					if(contentEmail.equals(jTextFieldPasswordR.getText())){
						try {
							Sql.setUser(jTextFieldNameR.getText(), jTextFieldPasswordR.getText(), jTextFieldEmail.getText());
						} catch (ClassNotFoundException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						contentEmail="";
						try {
							arrayListUser=Sql.getArrayListUser(jTextFieldNameR.getText());
							arrayListPetId=Sql.getArrayListPetId(arrayListUser.get(0));
						} catch (ClassNotFoundException | SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						creatJFramePets();
					}else{
						JOptionPane.showMessageDialog(null, "输入密码与邮箱内初始密码不一致", "消息提示",
								JOptionPane.INFORMATION_MESSAGE);
					}
				}
				
			}
		});
		//设置首页按钮功能
		jButtonHome.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.out.println("点击首页");
				creatJFramePets();
				
			}
		});
		
		//初始登录jPanelLogin
		jPanelLogin.setLayout(null);
		jPanelLogin.setBounds(0, 0, 200, 200);
		jLabelNameL.setBounds(3, 0, 47, 50);
		jTextFieldNameL.setBounds(50, 0, 150, 50);
		jLabelPasswordL.setBounds(3, 50, 47, 50);
		jTextFieldPasswordL.setBounds(50, 50, 150, 50);
		jButtonRegister.setBounds(0, 100, 100, 100);
		jButtonLogin.setBounds(100, 100, 100, 100);
		jPanelLogin.add(jLabelNameL);
		jPanelLogin.add(jTextFieldNameL);
		jPanelLogin.add(jLabelPasswordL);
		jPanelLogin.add(jTextFieldPasswordL);
		jPanelLogin.add(jButtonRegister);
		jPanelLogin.add(jButtonLogin);
		//初始注册jPanelRegister
		jPanelRegister.setLayout(null);
		jPanelRegister.setBounds(0, 0, 200, 250);
		jLabelNameR.setBounds(3, 0, 47, 50);
		jTextFieldNameR.setBounds(50, 0, 150, 50);
		jLabelEmail.setBounds(3, 50, 47, 50);
		jTextFieldEmail.setBounds(50, 50, 150, 50);
		jLabelPasswordR.setBounds(3, 100, 47, 50);
		jTextFieldPasswordR.setBounds(50, 100, 150, 50);
		jButtonSend.setBounds(0, 150, 100, 100);
		jButtonConfirm.setBounds(100, 150, 100, 100);
		jPanelRegister.add(jLabelNameR);
		jPanelRegister.add(jTextFieldNameR);
		jPanelRegister.add(jLabelEmail);
		jPanelRegister.add(jTextFieldEmail);
		jPanelRegister.add(jLabelPasswordR);
		jPanelRegister.add(jTextFieldPasswordR);
		jPanelRegister.add(jButtonSend);
		jPanelRegister.add(jButtonConfirm);
		//初始顶边栏jPanelTitle
		jPanelTitle.setLayout(null);
		jPanelTitle.setBounds(0, 0, 800, 47);
		jPanelTitle.setBorder(new BevelBorder(BevelBorder.RAISED));
		jPanelTitle.add(jButtonHome);
		jPanelTitle.add(jLabelTitle);
		jPanelTitle.add(jButtonMine);
		jButtonHome.setBounds(0, 0, 50, 47);
		jLabelTitle.setBounds(50, 0, 675, 47);
		jButtonMine.setBounds(725, 0, 75, 47);
		//初始jScrollPaneAnimals
		jScrollPaneAnimals.setLayout(null);
		jScrollPaneAnimals.setBounds(0, 47, 800,553);
		for(int i=1;i<13;i++){
			try {
				setJPanelAnimal(i, (i-1)*44,jScrollPaneAnimals);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//初始jScrollPaneShowAnimals
		jScrollPaneShowAnimal.setLayout(null);
		jScrollPaneShowAnimal.setBounds(0, 47, 800, 553);
		jTextAreaComment.setBounds(0, 0, 400, 530);
		jTextAreaComment.setBorder(BorderFactory.createLineBorder(Color.green));
		jTextAreaPet.setBounds(400, 0, 400, 240);
		jTextAreaPet.setEditable(false);
		jTextAreaPet.setBorder(BorderFactory.createLineBorder(Color.green));
		jButtonBuy.setBounds(400, 240, 400, 45);
		jButtonBuy.addActionListener(actionListenerJButtonBuy);
		jTextAreaSetComment.setBounds(400, 285, 400, 198);
		jTextAreaSetComment.setBorder(BorderFactory.createLineBorder(Color.green));
		jButtonComment.setBounds(400, 483, 400, 48);
		jButtonComment.addActionListener(actionListenerJButtonComment);
		jScrollPaneShowAnimal.add(jTextAreaComment);
		jScrollPaneShowAnimal.add(jTextAreaPet);
		jScrollPaneShowAnimal.add(jButtonBuy);
		jScrollPaneShowAnimal.add(jTextAreaSetComment);
		jScrollPaneShowAnimal.add(jButtonComment);
		//初始jLabelMine
		jLabelMine.setBounds(0, 47, 800, 75);
		jLabelMine.setFont(new Font("宋体",Font.BOLD, 16));
		
		container.setLayout(null);
		jFrame.setVisible(true);
		jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
	
	/*-----------------------------------------------------------------------------------------------------------------*/
	
	public void sendEmail(String emailUrl,String subject,String contentEmail){
		System.out.println("正在向邮箱："+emailUrl+"发送注册邮件");
		System.out.println("邮箱内密码："+contentEmail);
		
		Properties propertiesS=System.getProperties();
		MailAuthenticator mailAuthenticator=new MailAuthenticator("wudijiefangjun@sina.com", "233233");
		propertiesS.put("mail.smtp.auth", "true");
		propertiesS.put("mail.smtp.host", "smtp.sina.com");
		propertiesS.put("mail.transport.protocol", "smtp");
		Session sessionS=Session.getInstance(propertiesS, mailAuthenticator);
		MimeMessage message=new MimeMessage(sessionS);
		
		try {
			message.setFrom(new InternetAddress("wudijiefangjun@sina.com"));
			message.setRecipient(RecipientType.TO, new InternetAddress(emailUrl));
			message.setSubject(subject);
			message.setContent(contentEmail, "text/html;charset=utf-8");
			Transport.send(message);
			System.out.println("邮件已经成功发送");
		} catch (MessagingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}
	
	public void creatJFrameRegister(){
		container.removeAll();		
		container.add(jPanelRegister);
		container.repaint();
		System.out.println("注册界面");
		jFrame.setTitle("欢迎注册pets");
		jFrame.setBounds(0, 0, 200, 273);
		
	}
	
	public void creatJFrameLogin(){
		container.removeAll();
		container.add(jPanelLogin);
		container.repaint();
		System.out.println("登录界面");	
		jFrame.setTitle("欢迎登录pets");
		jFrame.setBounds(0, 0, 200, 223);
	}
	
	public void creatJFrameMine(String user_name) throws ClassNotFoundException, SQLException{
		container.removeAll();
		
		jLabelTitle.setText("上上上上上，上pets找宠物");
		String emailUrl=arrayListUser.get(2);
		String money=arrayListUser.get(3);
		jLabelMine.setText(user_name+"    邮箱："+emailUrl+"   余额："+money+"   拥有："+String.valueOf(arrayListPetId.size())+"个宠物");
		
		for(int i=0;i<arrayListPetId.size();i++){
			int petId=Integer.valueOf(arrayListPetId.get(i));
			
			String name=arrayListPet.get((petId-1)*6);
			String eat=arrayListPet.get(1+(petId-1)*6);
			String drink=arrayListPet.get(2+(petId-1)*6);
			String live=arrayListPet.get(3+(petId-1)*6);
			String hobby=arrayListPet.get(4+(petId-1)*6);
			String price=arrayListPet.get(5+(petId-1)*6);
			
			JPanel a=new JPanel();
			JLabel b=new JLabel("",JLabel.CENTER);
			JButton c=new JButton(); 
			
			c.setText("评论");
			c.setBounds(725,0, 75, 44);
			c.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					System.out.println("点击评论第"+petId+"个宠物： "+name);
					try {
						creatJFramePet(petId);
					} catch (ClassNotFoundException | SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});
			
			b.setText(String.valueOf(petId)+")  name:"+name+"  eat:"+eat+"  drink:"+drink+"  live:"+live+"  hobby:"+hobby+"  price:"+price);
			b.setBounds(3,0,722, 44);
			b.setBorder(BorderFactory.createLineBorder(Color.green));
			
			a.setLayout(null);
			a.setBounds(0, 122+i*44, 800, 44);
			a.add(c);
			a.add(b);
			
			container.add(a);
		}
		
		container.add(jPanelTitle);
		container.add(jLabelMine);
		container.repaint();
		System.out.println(user_name+"的主页");
		jFrame.setTitle(user_name+"的主页");
		jFrame.setBounds(0, 0, 800, 147+44*(arrayListPetId.size()));
		
	}
	
	public void setJPanelAnimal(int petId,int y,JScrollPane pets) throws ClassNotFoundException, SQLException{
		
		String name=arrayListPet.get(0+(petId-1)*6);
		String hobby=arrayListPet.get(4+(petId-1)*6);
		String price=arrayListPet.get(5+(petId-1)*6);
		
		JPanel a=new JPanel();
		JLabel b=new JLabel("",JLabel.CENTER);
		JButton c=new JButton(); 
		
		c.setText("查看");
		c.setBounds(725, 0, 75, 44);
		c.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.out.println("点击查看第"+petId+"个宠物： "+name);
				try {
					creatJFramePet(petId);
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		
		b.setText(String.valueOf(petId)+")  name:"+name+"  hobby:"+hobby+"  price:"+String.valueOf(price));
		b.setBounds(3, 0, 722, 44);
		b.setBorder(BorderFactory.createLineBorder(Color.green));
		
		a.setLayout(null);
		a.setBounds(0, y, 800, 44);
		a.add(c);
		a.add(b);
		pets.add(a);
	}
	
	public void creatJFramePets() {
		container.removeAll();
		
		jLabelTitle.setText("点击查看你想要购买的宠物的详细信息");
		
		container.add(jPanelTitle);
		container.add(jScrollPaneAnimals);
		container.repaint();
		System.out.println("宠物界面");
		jFrame.setTitle("pets");
		jFrame.setBounds(0, 0, 800, 600);
	}
	
	public boolean isEmail(String jTextFieldEmail){
		System.out.println("正在验证邮箱格式,输入邮箱为: "+jTextFieldEmail);
		String stringEmail="^([a-zA-Z0-9]*[-_]?[a-zA-Z0-9]+)*@([a-zA-Z0-9]*[-_]?[a-zA-Z0-9]+)+[\\.][A-Za-z]{2,3}([\\.][A-Za-z]{2})?$";
	    Pattern pattern = Pattern.compile(stringEmail);     
	    Matcher matcher = pattern.matcher(jTextFieldEmail);         
	    return matcher.matches(); 
	}
	
	public void creatJFramePet(int petId) throws ClassNotFoundException, SQLException{
		String name=arrayListPet.get(0+(petId-1)*6);
		String eat=arrayListPet.get(1+(petId-1)*6);
		String drink=arrayListPet.get(2+(petId-1)*6);
		String live=arrayListPet.get(3+(petId-1)*6);
		String hobby=arrayListPet.get(4+(petId-1)*6);
		String price=arrayListPet.get(5+(petId-1)*6);
		
		container.removeAll();
		
		jLabelTitle.setText(String.valueOf(petId)+"号宠物");
		jTextAreaSetComment.setText("购买后可以提交英文评价");
		
		jTextAreaComment.setText("");
		jTextAreaComment.append("用户购买评论：\n");
		ArrayList<String> arrayListComment =Sql.getArrayListComment(petId);
		for(int i=0;i<arrayListComment.size()/3;i++){
			jTextAreaComment.append(arrayListComment.get(1+i*3)+"\n");
			jTextAreaComment.append(arrayListComment.get(0+i*3)+":   "+arrayListComment.get(2+i*3)+"\n\n");
		}
		
		jTextAreaPet.setText("");
		jTextAreaPet.append("name: "+name+"\neat: "+eat+"\ndrink: "+drink+"\nlive: "+live+"\nhobby: "+hobby+"\nprice: "+price);
		//设置购买按钮功能
		jButtonBuy.removeActionListener(actionListenerJButtonBuy);
		actionListenerJButtonBuy=new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.out.println("点击购买");
				int money=Integer.valueOf(arrayListUser.get(3));
				int price=Integer.valueOf(arrayListPet.get(5+(petId-1)*6));	
				if(money>=price){
					try {
						Sql.buy(arrayListUser.get(0), petId);
						Sql.setPetId(arrayListUser.get(0), petId);
						arrayListPetId=Sql.getArrayListPetId(arrayListUser.get(0));
						arrayListUser=Sql.getArrayListUser(arrayListUser.get(0));
					} catch (ClassNotFoundException | SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					JOptionPane.showMessageDialog(null, "购买"+petId+"号宠物成功", "消息提示",
							JOptionPane.INFORMATION_MESSAGE);
				}else{
					JOptionPane.showMessageDialog(null,"对不起，你的余额不足", "消息提示",
							JOptionPane.INFORMATION_MESSAGE);
				}
			}
		};
		jButtonBuy.addActionListener(actionListenerJButtonBuy);
		//设置评价按钮功能
		jButtonComment.removeActionListener(actionListenerJButtonComment);
		actionListenerJButtonComment=new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.out.println("点击提交评价");
				try {
					if(Sql.getPet(arrayListPetId, petId)){
						String comment=jTextAreaSetComment.getText();
						Date date=new Date();
						String time=String.valueOf(date);
						Sql.setComment(petId, arrayListUser.get(0), time, comment);
						JOptionPane.showMessageDialog(null, "评论成功\n再次进入宠物查看界面即能查看添加的评论", "消息提示",
								JOptionPane.INFORMATION_MESSAGE);
					}else{
						JOptionPane.showMessageDialog(null,"对不起，请先购买宠物才能进行评论", "消息提示",
								JOptionPane.INFORMATION_MESSAGE);
					}
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		};
		jButtonComment.addActionListener(actionListenerJButtonComment);
		
		
		
		container.add(jPanelTitle);
		container.add(jScrollPaneShowAnimal);
		container.repaint();
		System.out.println("第"+petId+"个宠物的界面");
		jFrame.setTitle("宠物信息");
		jFrame.setBounds(0, 0, 800, 600);
		
	}
	/*-----------------------------------------------------------------------------------------------------------------*/

	public static void main(String[] args){
		Gui gui=new Gui();
		gui.creatJFrameLogin();
	}

}
